//
//  RishabhPT_WeatherAppTests.swift
//  RishabhPT-WeatherAppTests
//
//  Created by Pratik Pandya on 29/05/23.
//

import XCTest
@testable import RishabhPT_WeatherApp

final class RishabhPT_WeatherAppTests: XCTestCase {
    
    var session: URLSession!
        var url: URL!
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
        
        session = URLSession(configuration: .default)
        url = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=22.30504255328568&lon=70.75379483152548&units=metric&appid=ae1c4977a943a50eaa7da25e6258d8b2")
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
        session = nil
        url = nil
    }

    func testExample() throws {
        // This is an example of a functional test case.
        // Use XCTAssert and related functions to verify your tests produce the correct results.
        // Any test you write for XCTest can be annotated as throws and async.
        // Mark your test throws to produce an unexpected failure when your test encounters an uncaught error.
        // Mark your test async to allow awaiting for asynchronous code to complete. Check the results with assertions afterwards.
    }

    func testPerformanceExample() throws {
        // This is an example of a performance test case.
        self.measure {
            // Put the code you want to measure the time of here.
            
            
        }
    }
    
    func testAPICall() {
            // Create an expectation for the API response
            let expectation = XCTestExpectation(description: "API Response")
            
            // Create a data task with a mock URL session
            let dataTask = session.dataTask(with: url) { (data, response, error) in
                // Perform assertions on the response
                XCTAssertNil(error)
                XCTAssertNotNil(data)
                XCTAssertEqual((response as? HTTPURLResponse)?.statusCode, 200)

                // Fulfill the expectation
                expectation.fulfill()
            }
            
            // Start the data task
            dataTask.resume()
            
            // Wait for the expectation to be fulfilled with a timeout
            wait(for: [expectation], timeout: 5.0)
        }

}
