//
//  ModelClassFile.swift
//  RishabhPT-WeatherApp
//
//  Created by Pratik Pandya on 29/05/23.
//

import Foundation
import UIKit
import Alamofire
import AlamofireImage

class ModelClass {
    
    typealias array = [Any]
    typealias dictionary = [String:Any]
    typealias images = UIImage
    
    class func GetJSONDataFromAPI(URL:String, completion:@escaping (dictionary?,array?,String?) -> Void){
        
        AF.request(URL).responseJSON { response in
            switch(response.result){
            case.failure(let error):
                completion(nil,nil,error.localizedDescription)
            case.success(let value):
                
                if (value as? [Any]) != nil{
                    completion(nil,value as? [Any],nil)
                }else if  (value as? [String:Any]) != nil
                {
                    completion(value as? [String:Any], nil, nil)
                }else{
                    print("Dictionary or array not found")
                }
                
            }
        }
    }
    
    class func GetJSONDataFromParameter(URL:String,Passarameters:[String:Any],completion:@escaping (dictionary?,array?,String?) -> Void)  {
        
        AF.request(URL, method: HTTPMethod.post, parameters: Passarameters as Parameters, encoding: URLEncoding.default).responseJSON { (response:AFDataResponse) in
            switch(response.result){
            case.failure(let error):
                completion(nil,nil,error.localizedDescription)
            case.success(let value):
                
                if (value as? [Any]) != nil{
                    completion(nil,value as? [Any],nil)
                }else if  (value as? [String:Any]) != nil
                {
                    completion(value as? [String:Any], nil, nil)
                }else{
                    print("Dictionary or array not found")
                }
                
            }
        }
    }
    
    class func DownloadImage(url: String, completion: @escaping (images) -> Void ){
        
        var images = UIImage()
        let dispatchGroup = DispatchGroup()
        dispatchGroup.enter()
        
        let url = URL(string: url)!
        AF.request(url.absoluteString).responseImage { response in
            
            switch(response.result){
            case .success(let img):
                images = img
                completion(images)
                dispatchGroup.leave()
            case .failure(let err):
                print(err.localizedDescription)
                dispatchGroup.leave()
            }
        }
    }
    
}


extension UIImageView{
    func DownloadImage(url:String){
        let dispatchGroup = DispatchGroup()
        dispatchGroup.enter()
        AF.request(url).responseImage { [weak self] (result) in
            switch(result.result){
            case .success(let value):
                //self?.image = UIImage(data: value.lowestQualityJPEGNSData)
                //self?.image = value
                weak var image = value
                self?.image = UIImage(data: image!.lowestQualityJPEGNSData)
                dispatchGroup.leave()
            case .failure(let error):
                print(error.localizedDescription)
                dispatchGroup.leave()
            }
        }
    }
}

extension UIImage {

    var highestQualityJPEGNSData: Data { return self.jpegData(compressionQuality: 1.0)! }
    var highQualityJPEGNSData: Data    { return self.jpegData(compressionQuality: 0.75)!}
    var mediumQualityJPEGNSData: Data  { return self.jpegData(compressionQuality: 0.5)! }
    var lowQualityJPEGNSData: Data     { return self.jpegData(compressionQuality: 0.25)!}
    var lowestQualityJPEGNSData: Data  { return self.jpegData(compressionQuality: 0.0)! }

}

//extension UIImage {
//
//    func compress(maxKb: Double) -> Data? {
//        let quality: CGFloat = maxKb / self.sizeAsKb()
//        let compressedData: Data? = self.jpegData(compressionQuality: quality)
//        return compressedData
//    }
//
//    func sizeAsKb() -> Double {
//        Double(self.pngData()?.count ?? 0 / 1024)
//    }
//}
