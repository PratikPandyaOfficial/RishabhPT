//
//  ConstantFile.swift
//  RishabhPT-WeatherApp
//
//  Created by Pratik Pandya on 29/05/23.
//

import Foundation

var APIkey = ""

struct url{
    static var mainURL = "https://api.openweathermap.org/data/2.5/weather"
}
