//
//  DataClassFile.swift
//  RishabhPT-WeatherApp
//
//  Created by Pratik Pandya on 29/05/23.
//

import Foundation

class Weather{
    var cod: Int
    var name: String
    var wind: Wind
    var main: Main
    
    init(data:[String:Any]) {
        self.cod = data["cod"] as? Int ?? 0
        self.name = data["name"] as? String ?? "N/A"
        let windresultdata = data["wind"] as? [String:Any] ?? [String:Any]()
        self.wind = Wind(data: windresultdata)
        let mainresultdata = data["main"] as? [String:Any] ?? [String:Any]()
        self.main = Main(data: mainresultdata)
    }
}

class Main{
    var temp: Double
    var temp_min: Double
    var temp_max: Double
    var humidity: Int
    
    init(data:[String:Any]) {
        self.temp = data["temp"] as? Double ?? 0.0
        self.temp_min = data["temp_min"] as? Double ?? 0.0
        self.temp_max = data["temp_max"] as? Double ?? 0.0
        self.humidity = data["humidity"] as? Int ?? 0
    }
}

class Wind{
    var speed: Double
    
    init(data:[String:Any]) {
        self.speed = data["speed"] as? Double ?? 0.0
    }
}
