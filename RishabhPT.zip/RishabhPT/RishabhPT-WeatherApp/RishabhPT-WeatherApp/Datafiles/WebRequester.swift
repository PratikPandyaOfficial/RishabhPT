//
//  WebRequester.swift
//  RishabhPT-WeatherApp
//
//  Created by Pratik Pandya on 29/05/23.
//

import Foundation
import ARKit

class WebRequester{
    
    static var shared = WebRequester()
    
    
    
    func getLocationDetails(parameter:[String:Any], success:@escaping(Weather) -> Void){
        
        //ModelClass.GetJSONDataFromAPI(URL: "\(url.mainURL)?lat=22.303894&lon=70.802162&units=metric&cnt=7&appid=\(APIkey)")
        ModelClass.GetJSONDataFromAPI(URL: "\(url.mainURL)?lat=\(parameter["lat"] ?? "")&lon=\(parameter["lon"] ?? "")&units=metric&appid=\(APIkey)")
        { dic, arr, err in
            if err == nil{
                let data = dic ?? [String:Any]()
                success(Weather(data: data))
            }
            else{
                print(err)
                //timeOut(err: err!)
            }
        }
    }
    
}
