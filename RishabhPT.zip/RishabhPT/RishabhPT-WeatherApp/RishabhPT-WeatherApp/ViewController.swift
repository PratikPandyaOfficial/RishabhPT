//
//  ViewController.swift
//  RishabhPT-WeatherApp
//
//  Created by Pratik Pandya on 29/05/23.
//

import UIKit
import GooglePlaces
import CoreLocation

class ViewController: UIViewController, GMSAutocompleteViewControllerDelegate, CLLocationManagerDelegate {
    
    
    @IBOutlet weak var lblCityName: UILabel!
    @IBOutlet weak var lblTemp: UILabel!
    @IBOutlet weak var lblMinTemp: UILabel!
    @IBOutlet weak var lblMaxTemp: UILabel!
    @IBOutlet weak var lblHumidity: UILabel!
    @IBOutlet weak var lblWindSpeed: UILabel!
    
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //let param = ["lat":"22.303894","lon":"70.802162"]
        getLocation()
    }
    
    func getLocationDetail(lat:String, long:String){
        PPOLoader.showLoadingView()
        let param = ["lat":lat,"lon":long]
        print(param)
        WebRequester.shared.getLocationDetails(parameter: param) { data in
            print(data)
            self.lblCityName.text = data.name
            self.lblTemp.text = "\(data.main.temp)°"
            self.lblHumidity.text = "\(data.main.humidity)"
            self.lblMinTemp.text = "\(data.main.temp_min)°"
            self.lblMaxTemp.text = "\(data.main.temp_max)°"
            self.lblWindSpeed.text = "\(data.wind.speed)"
            PPOLoader.hideLoadingView()
        }
    }
    
    @IBAction func btnSearchLocation(_ sender: UIButton) {
        let autocompleteController = GMSAutocompleteViewController()
            autocompleteController.delegate = self

            // Specify the place data types to return.
            let fields: GMSPlaceField =
        GMSPlaceField(rawValue:                                             UInt(GMSPlaceField.name.rawValue) |
            UInt(GMSPlaceField.placeID.rawValue) |
            UInt(GMSPlaceField.coordinate.rawValue) |
            GMSPlaceField.addressComponents.rawValue |
            GMSPlaceField.formattedAddress.rawValue)
            autocompleteController.placeFields = fields

            // Specify a filter.
//            let filter = GMSAutocompleteFilter()
//            filter.type = .address
//            autocompleteController.autocompleteFilter = filter

            // Display the autocomplete view controller.
            present(autocompleteController, animated: true, completion: nil)
    }
    

    func viewController(_ viewController: GMSAutocompleteViewController, didAutocompleteWith place: GMSPlace) {
        print("Place name: \(place.name ?? "")")
            print("Place ID: \(place.placeID ?? "")")
            print("Place attributions: \(place.attributions)")
            print("Place address: \(place.formattedAddress ?? "")")
        print("Place address: \(place.addressComponents)")
        
        
        print(place.coordinate.latitude, place.coordinate.longitude)
        
        getLocationDetail(lat: "\(place.coordinate.latitude)", long: "\(place.coordinate.longitude)")
        
        
            dismiss(animated: true, completion: nil)
    }

    func viewController(_ viewController: GMSAutocompleteViewController, didFailAutocompleteWithError error: Error) {
        print("Error: ", error.localizedDescription)
    }
    
    func wasCancelled(_ viewController: GMSAutocompleteViewController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func getLocation(){
        
        // Ask for Authorisation from the User.
        self.locationManager.requestAlwaysAuthorization()

        // For use in foreground
        self.locationManager.requestWhenInUseAuthorization()
        DispatchQueue.global().async {
            if CLLocationManager.locationServicesEnabled() {
                self.locationManager.delegate = self
                self.locationManager.desiredAccuracy = kCLLocationAccuracyNearestTenMeters
                self.locationManager.startUpdatingLocation()
            }
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locValue: CLLocationCoordinate2D = manager.location?.coordinate else { return }
        print("locations = \(locValue.latitude) \(locValue.longitude)")
        locationManager.stopUpdatingLocation()
        getLocationDetail(lat: "\(locValue.latitude)", long: "\(locValue.longitude)")
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
    }
}
